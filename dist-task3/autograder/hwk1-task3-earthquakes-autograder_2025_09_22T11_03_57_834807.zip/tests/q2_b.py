OK_FORMAT = True

test = {   'name': 'q2_b',
    'points': 2,
    'suites': [{'cases': [{'code': '>>> assert raw_eqk_shape_type == tuple\n', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}

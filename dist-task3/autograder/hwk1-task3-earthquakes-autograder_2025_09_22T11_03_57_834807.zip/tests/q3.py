OK_FORMAT = True

test = {   'name': 'q3',
    'points': 2,
    'suites': [   {   'cases': [{'code': '>>> unique_events.tolist() == list(raw_eqk.type.unique())\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}

OK_FORMAT = True

test = {'name': 'q2_c', 'points': 2, 'suites': [{'cases': [{'code': '>>> num_rows == 120108\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}

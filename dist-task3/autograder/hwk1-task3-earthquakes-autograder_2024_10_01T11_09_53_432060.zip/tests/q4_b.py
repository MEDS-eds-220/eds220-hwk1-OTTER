OK_FORMAT = True

test = {   'name': 'q4_b',
    'points': 1,
    'suites': [   {   'cases': [{'code': ">>> assert pd.read_csv('data/t3_q4b_df.csv',  index_col=0).equals(eqk_3)\nTrue", 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}

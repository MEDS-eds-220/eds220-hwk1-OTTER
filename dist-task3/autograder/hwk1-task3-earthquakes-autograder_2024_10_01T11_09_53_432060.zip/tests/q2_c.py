OK_FORMAT = True

test = {'name': 'q2_c', 'points': 1, 'suites': [{'cases': [{'code': '>>> num_rows == 120108\nTrue', 'hidden': True, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}

OK_FORMAT = True

test = {   'name': 'q1_c',
    'points': 2,
    'suites': [   {   'cases': [{'code': ">>> assert pd.read_csv('data/t3_q1c_df.csv', index_col=0).equals(raw_eqk_head)\n", 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}

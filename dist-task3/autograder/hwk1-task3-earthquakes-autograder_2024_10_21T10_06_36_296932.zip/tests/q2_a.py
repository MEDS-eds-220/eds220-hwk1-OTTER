OK_FORMAT = True

test = {   'name': 'q2_a',
    'points': 2,
    'suites': [{'cases': [{'code': '>>> raw_eqk_shape == (120108, 8)\nTrue', 'hidden': True, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}

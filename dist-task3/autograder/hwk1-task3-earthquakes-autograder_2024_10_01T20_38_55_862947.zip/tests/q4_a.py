OK_FORMAT = True

test = {   'name': 'q4_a',
    'points': 1,
    'suites': [   {   'cases': [{'code': ">>> assert pd.read_csv('data/t3_q4a_df.csv', index_col=0).equals(eqk)\n", 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}

OK_FORMAT = True

test = {   'name': 'q2_b',
    'points': 1,
    'suites': [{'cases': [{'code': '>>> assert raw_eqk_shape_type == tuple\n', 'hidden': True, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}

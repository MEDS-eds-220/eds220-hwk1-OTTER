OK_FORMAT = True

test = {   'name': 'q2_2',
    'points': 1,
    'suites': [   {   'cases': [{'code': '>>> assert raw_eqk_shape_type == tuple, "Expected raw_eqk_shape_type to be tuple"\n', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}

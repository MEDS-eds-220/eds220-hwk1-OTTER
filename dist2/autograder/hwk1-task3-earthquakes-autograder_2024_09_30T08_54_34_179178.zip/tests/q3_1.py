OK_FORMAT = True

test = {   'name': 'q3_1',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': ">>> solution = np.array(['earthquake', 'quarry blast', 'quarry', 'mining explosion',\n"
                                               "...                             'rock burst', 'explosion', 'landslide', 'sonicboom', \n"
                                               "...                             'sonic boom', 'anthropogenic event', 'acoustic noise'], \n"
                                               '...                             dtype=object)\n'
                                               '>>> \n'
                                               '>>> \n'
                                               '>>> np.array_equal(unique_events, solution)\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}

OK_FORMAT = True

test = {   'name': 'q7_1',
    'points': 1,
    'suites': [   {   'cases': [{'code': '>>> top20[0] == 8.2\nTrue', 'hidden': True, 'locked': False}, {'code': '>>> top20[19] == 6.9\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}

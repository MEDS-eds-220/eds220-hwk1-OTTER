OK_FORMAT = True

test = {   'name': 'q4_3',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> len(eqk_3) == 3\nTrue', 'hidden': True, 'locked': False},
                                   {'code': '>>> eqk.place[0] == "26km S of Redoubt Volcano, Alaska"\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}

OK_FORMAT = True

test = {   'name': 'q2_2',
    'points': None,
    'suites': [   {   'cases': [{'code': '>>> assert raw_eqk_shape_type == tuple, f"Expected {tuple}, but got {raw_eqk_shape_type}"\n>>> \n', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}

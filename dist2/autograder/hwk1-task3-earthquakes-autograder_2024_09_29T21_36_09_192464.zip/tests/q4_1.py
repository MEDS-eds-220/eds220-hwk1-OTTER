OK_FORMAT = True

test = {'name': 'q4_1', 'points': None, 'suites': [{'cases': [{'code': ">>> eqk.index.name == 'id'\nTrue", 'hidden': True, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}

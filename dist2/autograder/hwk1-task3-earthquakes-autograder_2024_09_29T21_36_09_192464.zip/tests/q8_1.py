OK_FORMAT = True

test = {   'name': 'q8_1',
    'points': 2,
    'suites': [   {   'cases': [   {'code': '>>> top20_filtered.depth[11] == 16.54\nTrue', 'hidden': True, 'locked': False},
                                   {'code': '>>> len(top20_filtered) == 20\nTrue', 'hidden': True, 'locked': False},
                                   {'code': '>>> len(top20_filtered.columns) == 3\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}

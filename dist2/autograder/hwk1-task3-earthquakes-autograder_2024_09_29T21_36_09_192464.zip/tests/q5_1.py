OK_FORMAT = True

test = {'name': 'q5_1', 'points': None, 'suites': [{'cases': [{'code': '>>> omitted_events == 1710\nTrue', 'hidden': True, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}

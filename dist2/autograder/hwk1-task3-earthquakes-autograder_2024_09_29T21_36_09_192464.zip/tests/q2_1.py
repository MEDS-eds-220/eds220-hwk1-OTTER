OK_FORMAT = True

test = {   'name': 'q2_1',
    'points': None,
    'suites': [{'cases': [{'code': '>>> raw_ekq_shape == (120108, 8)\nTrue', 'hidden': True, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}

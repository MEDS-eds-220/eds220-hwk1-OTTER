OK_FORMAT = True

test = {   'name': 'q14',
    'points': 1,
    'suites': [   {   'cases': [{'code': ">>> assert pd.read_csv('data/q14_df.csv', index_col=0).equals(subset_na)\n", 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}

OK_FORMAT = True

test = {   'name': 'q3_d',
    'points': 1,
    'suites': [   {   'cases': [{'code': ">>> assert pd.read_csv('data/3d_df.csv').equals(first_8_rows)\n", 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}

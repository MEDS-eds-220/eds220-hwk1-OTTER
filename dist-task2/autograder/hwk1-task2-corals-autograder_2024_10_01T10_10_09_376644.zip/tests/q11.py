OK_FORMAT = True

test = {   'name': 'q11',
    'points': 2,
    'suites': [   {   'cases': [{'code': ">>> assert pd.read_csv('data/q11_df.csv',  index_col=0).equals(subset)\n", 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}

OK_FORMAT = True

test = {'name': 'q6', 'points': 1, 'suites': [{'cases': [{'code': '>>> unique_observers == 16\nTrue', 'hidden': True, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}

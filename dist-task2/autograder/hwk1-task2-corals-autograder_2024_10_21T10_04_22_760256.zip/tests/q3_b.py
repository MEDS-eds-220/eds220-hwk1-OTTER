OK_FORMAT = True

test = {   'name': 'q3_b',
    'points': 2,
    'suites': [   {   'cases': [{'code': '>>> expected_column_names = coral_div.columns.tolist()\n>>> list(coral_div_columns) == expected_column_names\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}

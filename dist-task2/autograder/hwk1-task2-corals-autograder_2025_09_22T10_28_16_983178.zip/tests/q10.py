OK_FORMAT = True

test = {   'name': 'q10',
    'points': 2,
    'suites': [   {   'cases': [{'code': ">>> assert pd.read_csv('data/q10_df.csv', index_col=0).equals(sampling_2017)\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}

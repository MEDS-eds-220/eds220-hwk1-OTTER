OK_FORMAT = True

test = {'name': 'q6', 'points': 2, 'suites': [{'cases': [{'code': '>>> unique_observers == 16\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}

OK_FORMAT = True

test = {   'name': 'q3_a',
    'points': 2,
    'suites': [   {   'cases': [{'code': '>>> rows == 575\nTrue', 'hidden': True, 'locked': False}, {'code': '>>> columns == 42\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}

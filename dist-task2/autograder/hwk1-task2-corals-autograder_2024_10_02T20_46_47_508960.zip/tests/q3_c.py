OK_FORMAT = True

test = {   'name': 'q3_c',
    'points': 2,
    'suites': [{'cases': [{'code': '>>> assert coral_div_types.equals(coral_div.dtypes)\n', 'hidden': True, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
